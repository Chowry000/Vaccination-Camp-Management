package com.neu.webtools.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;

import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Staff;
import com.neu.webtools.Pojo.Vaccinator;




public class StaffDao extends DAO {
	
	public StaffDao()
	{
		// Need to remove this into a method. Just here so that the Tables in hibernate can be created
		
		//begin();
		//Query q = getSession().createQuery("from Hospital");
		
		
		
		
	}
	
	

	
	public List<Staff> searchVaccinator()
	{
		begin();
		Query q = getSession().createQuery("from Staff where role = 'Vaccinator'");
		
//		Criteria crit = getSession().createCriteria(Staff.class);
//			Staff staff = new Staff();
//			staff.setRole("Vaccinator");
//			crit.add(Example.create(staff));
			
		List<Staff> vaccinator = q.list();
		commit();
		return vaccinator;
	}
	
	public List<Staff> searchuserId(String s)
	{
		begin();
		//Query q = getSession().createQuery("Select userId from Staff");
		
		Criteria crit = getSession().createCriteria(Staff.class);
			Staff staff = new Staff();
			staff.setUserId(s);
			crit.add(Restrictions.eq("userId",s));
			
		List<Staff> userId =  crit.list();
		commit();
		return userId;
	}
	
	
	
	
	
	public String authenticateStaff(Staff s) throws UserException
    {
		String cred = "Invalid";
        try {
            begin();
            Criteria cr = getSession().createCriteria(Staff.class);
            cr.add(Restrictions.eq("userId", s.getUserId()));
            cr.add(Restrictions.eq("userPassword", s.getUserPassword()));
           // cr.add(Restrictions.eq(�userName�, b.getUserName()));
            
            try {
            Staff s1 = (Staff) cr.uniqueResult();
            String role = s1.getRole();
            if(role == null || role.contentEquals(""))
            return 	cred;
            
            else 
            return role;
            }
            catch(Exception e)
            {
            	return cred;
            	
            }
            
                
        } catch (HibernateException e) {
           return cred;
        }

    }
	
	
	

}
