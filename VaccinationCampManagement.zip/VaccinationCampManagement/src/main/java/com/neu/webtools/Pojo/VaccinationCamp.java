package com.neu.webtools.Pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class VaccinationCamp {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String location;
	private Date date;
	private String vaccinatorDuty;
	
	
	public VaccinationCamp() {}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String getVaccinatorDuty() {
		return vaccinatorDuty;
	}


	public void setVaccinatorDuty(String vaccinatorDuty) {
		this.vaccinatorDuty = vaccinatorDuty;
	}
	
		
}
