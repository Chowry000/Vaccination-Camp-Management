package com.neu.webtools.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Vaccine {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int vaccineId;
	
	@Column(name = "VaccineName")
	private String vaccineName;
	
	@Column(name = "Dosage")
	private float dosage;
	
	@Column(name = "VaccineType")
	private char vaccineType;
	
	public Vaccine() {}
	

	public int getVaccineId() {
		return vaccineId;
	}

	public void setVaccineId(int vaccineId) {
		this.vaccineId = vaccineId;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	public float getDosage() {
		return dosage;
	}

	public void setDosage(float dosage) {
		this.dosage = dosage;
	}

	public char getVaccineType() {
		return vaccineType;
	}

	public void setVaccineType(char vaccineType) {
		this.vaccineType = vaccineType;
	}
	
	

}
