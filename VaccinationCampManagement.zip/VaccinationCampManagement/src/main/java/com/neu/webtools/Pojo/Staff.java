package com.neu.webtools.Pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Staff {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int staffId;

	private String userId;
	private String fName;
	private String lName;
	
	private String userPassword;
	
	private String role;
	
	private int hospitalid;
	
	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name = "quarterId")
	private Address address;
	
	
	public Staff() {}


	
	
	public String getRole() {
		return role;
	}




	public void setRole(String role) {
		this.role = role;
	}




	public String getUserId() {
		return userId;
	}




	public void setUserId(String userId) {
		this.userId = userId;
	}




	public String getUserPassword() {
		return userPassword;
	}




	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}




	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}




	public Address getAddress() {
		return address;
	}




	public void setAddress(Address address) {
		this.address = address;
	}




	public int getStaffId() {
		return staffId;
	}




	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}




	public int getHospitalid() {
		return hospitalid;
	}




	public void setHospitalid(int hospitalid) {
		this.hospitalid = hospitalid;
	}
	
	
	
}
