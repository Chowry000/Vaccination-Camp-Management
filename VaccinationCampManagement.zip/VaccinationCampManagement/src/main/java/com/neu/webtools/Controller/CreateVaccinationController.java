package com.neu.webtools.Controller;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.webtools.Dao.BeneficiaryDao;
import com.neu.webtools.Dao.HospitalDao;
import com.neu.webtools.Dao.VaccinatorDao;
import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Beneficiary;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Vaccination;





@Controller
public class CreateVaccinationController {
	
	@Autowired
	HospitalDao hdao;
	
	@Autowired
	BeneficiaryDao bdao;

	@Autowired
	VaccinatorDao vdao;
	
	
	
	
	@RequestMapping(value  = "/CreateVaccination.htm", method = RequestMethod.POST)
	public String vaccinationCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException, ParseException 
	{
		
		
		
		String date = request.getParameter("vaccinationdate");
		int hospitalId = Integer.parseInt(request.getParameter("hospSelect"));
		int beneficiaryId = Integer.parseInt(request.getParameter("beneficiarySelect"));
		String vaccine = request.getParameter("vaccinelist");
			
			
			System.out.println("hospitalId");
			System.out.println(hospitalId);
			
		Vaccination vc = new Vaccination();
		vc.setDate(date);
		vc.setHospitalId(hospitalId);
		vc.setBeneficiaryId(beneficiaryId);
		vc.setVaccine(vaccine);
			
			vdao.vaccinate(vc);		
			List<Hospital> hospital = hdao.searchHospital();
			model.addAttribute("hospitallist", hospital);	
			
			List<Beneficiary> beneficiary = bdao.searchBeneficiary();
			model.addAttribute("beneficiarylist", beneficiary);
			
			model.addAttribute("vaccine", vaccine);
			
			
			return "VaccinatedSuccessful";
		
		
	}
	
	
	@RequestMapping(value  = "*/CreateVaccination.htm", method = RequestMethod.POST)
	public String vaccinationCreates(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException, ParseException 
	{
		
		
		
		String date = request.getParameter("vaccinationdate");
		int hospitalId = Integer.parseInt(request.getParameter("hospSelect"));
		int beneficiaryId = Integer.parseInt(request.getParameter("beneficiarySelect"));
		String vaccine = request.getParameter("vaccinelist");
			
			
			System.out.println("hospitalId");
			System.out.println(hospitalId);
			
		Vaccination vc = new Vaccination();
		vc.setDate(date);
		vc.setHospitalId(hospitalId);
		vc.setBeneficiaryId(beneficiaryId);
		vc.setVaccine(vaccine);
			
			vdao.vaccinate(vc);		
			List<Hospital> hospital = hdao.searchHospital();
			model.addAttribute("hospitallist", hospital);	
			
			List<Beneficiary> beneficiary = bdao.searchBeneficiary();
			model.addAttribute("beneficiarylist", beneficiary);
			
			model.addAttribute("vaccine", vaccine);
			
			
			return "VaccinatedSuccessful";
		
		
	}
	
	

}
