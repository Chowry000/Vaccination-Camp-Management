package com.neu.webtools.Pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int quarterId;
	
	@Column(name = "Street", nullable = false)
	private String street;
	
	@Column(name = "Zip", nullable = false)
	private int zip;
	
	/*@ManyToMany(mappedBy = "address")
	private Set<Staff> staff = new HashSet();*/

	public Address() {}
	
	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}
	
	
	
}
