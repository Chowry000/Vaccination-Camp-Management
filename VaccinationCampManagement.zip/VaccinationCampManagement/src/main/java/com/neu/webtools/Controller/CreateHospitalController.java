package com.neu.webtools.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.webtools.Dao.HospitalDao;
import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Hospital;





@Controller
public class CreateHospitalController {
	
	@Autowired
	HospitalDao hdao;
	
	
	@RequestMapping(value  = "/CreateHospital.htm", method = RequestMethod.GET)
	public String hospital(Model model,HttpServletRequest request,HttpServletResponse response) 
	{
		model.addAttribute("hospital", new Hospital());
			return "CreateHospital";
		
	}
	
	
	@RequestMapping(value  = "/CreateHospital.htm", method = RequestMethod.POST)
	public String hospitalCreate(@Valid @ModelAttribute("hospital") Hospital hospital, BindingResult result,HttpServletRequest request,HttpServletResponse response) 
	{
//		String hospitalName = request.getParameter("HName");
//		String city = request.getParameter("HCity");
//		String hospitalAddress= request.getParameter("HAddress");
//		
//		Hospital hospital = new Hospital();
//		
//		hospital.setHospitalName(hospitalName);
//		hospital.setCity(city);
//		hospital.setHospitalAddress(hospitalAddress);
		
if(result.hasErrors())
		{return "CreateHospital";}
		try {
			hdao.register(hospital);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return "HospitalSuccessful";
	
		
	}
	
	

}
