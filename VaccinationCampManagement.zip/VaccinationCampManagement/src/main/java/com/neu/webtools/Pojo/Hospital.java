package com.neu.webtools.Pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Hospital {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	
	@Column(name = "HospitalName")
	@NotNull(message = "Hospital Name may not be null")
	@Size(min=3, message = "Hospital Name must be atleast 3 characters")
	private String hospitalName;
	
	@Column(name = "City")
	@Size(min=3, message = "City must be atleast 3 characters")
	private String city;
	
	@Column(name = "HospitalAddress")
	@Size(min=5, message = "Hospital Address  must be atleast 5 characters")
	private String hospitalAddress;
	
	/*
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_HospitalId")
	private Set<Staff> staff = new HashSet<Staff>();
	*/
	
	
	public Hospital() {}

	
	
	public void setId(int id) {
		Id = id;
	}



	public int getId() {
		return Id;
	}



	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalAddress() {
		return hospitalAddress;
	}

	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

		
	

}
