package com.neu.webtools.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Beneficiary;
import com.neu.webtools.Pojo.Hospital;




public class BeneficiaryDao extends DAO {
	
	public BeneficiaryDao()
	{
		// Need to remove this into a method. Just here so that the Tables in hibernate can be created
		
		//begin();
		//Query q = getSession().createQuery("from Hospital");
		
		
		
		
	}
	
	public List<Beneficiary> searchBeneficiary()
	{
		begin();
		Query q = getSession().createQuery("from Beneficiary");
		
		List<Beneficiary> beneficiary = q.list();
		commit();
		return beneficiary;
	}
	
	
	
	public Beneficiary register(Beneficiary h) throws UserException {
		try {
			begin();
			getSession().save(h);
			commit();
			return h;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}
	
	/*public List<Hospital> searchHospital()
	{
		begin();
		Query q = getSession().createQuery("from Hospital");
		
		List<Hospital> hospital = q.list();
		commit();
		return hospital;
	}
	
	
	public Hospital searchHospitalId(Hospital h) throws UserException
    {
        try {
            begin();
            Criteria cr = getSession().createCriteria(Hospital.class);
            cr.add(Restrictions.eq("Id", h.getId()));
           // cr.add(Restrictions.eq(�userName�, b.getUserName()));
            
            Hospital h1 = (Hospital) cr.uniqueResult();
            int hospitalId = h.getId();
            return h1;
                
        } catch (HibernateException e) {
           return null;
        }

    }
	
	
	*/

}
