package com.neu.webtools.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.webtools.Dao.BeneficiaryDao;
import com.neu.webtools.Dao.DoctorDao;
import com.neu.webtools.Dao.HospitalDao;
import com.neu.webtools.Dao.StaffDao;
import com.neu.webtools.Dao.VaccinationCampDao;
import com.neu.webtools.Dao.VaccinatorDao;
import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Address;
import com.neu.webtools.Pojo.Beneficiary;
import com.neu.webtools.Pojo.Doctor;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Vaccination;
import com.neu.webtools.Pojo.VaccinationCamp;
import com.neu.webtools.Pojo.Vaccinator;





@Controller
@RequestMapping(value  = "/Create/*")
public class CreateController {
	
	@Autowired
	DoctorDao ddao;
	
	@Autowired
	HospitalDao hdao;
	
	@Autowired
	VaccinatorDao vdao;
	
	@Autowired
	BeneficiaryDao bdao;
	
	@Autowired
	VaccinationCampDao vcdao;
	
	@Autowired
	StaffDao sdao;
	
	
		
	
	@RequestMapping(value  = "/CreateDoctor.htm", method = RequestMethod.POST)
	public String doctorCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		HttpSession session = request.getSession();
		
		String doctorFName = (String) session.getAttribute("FName");
		//System.out.println(doctorName);
		String doctorLName = (String) session.getAttribute("LName");
		String password= (String) session.getAttribute("password");
		Address address = (Address) session.getAttribute("address");
		String userId = (String) session.getAttribute("userId");
		int hospitalId =  (Integer) session.getAttribute("hospitalId");
		
		
		String speciality = request.getParameter("DSpeciality");
		
		
		Doctor doctor = new Doctor();
		
		
		doctor.setfName(doctorFName);
		doctor.setlName(doctorLName);
		doctor.setUserPassword(password);
		doctor.setAddress(address);
		doctor.setSpeciality(speciality);
		doctor.setHospitalid(hospitalId);
		doctor.setRole("Doctor");
		doctor.setUserId(userId);
		
		/*Hospital h = new Hospital();
		h.setId(hospitalId);
		h = hdao.searchHospitalId(h);
		
		h.setStaff(doctor);*/
		
		try {
			ddao.register(doctor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return "CreateDoctorSuccessful";
		
		
	}
	
	
	
	
	@RequestMapping(value  = "/CreateCamp.htm", method = RequestMethod.POST)
	public String campCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException, ParseException 
	{
				
		String location = request.getParameter("hospSelect");
		String vaccinator = request.getParameter("vaccinatorSelect");
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("vcdate"));
		System.out.println(date);
		
		VaccinationCamp vc = new VaccinationCamp();
		
		vc.setLocation(location);
		vc.setVaccinatorDuty(vaccinator);
		vc.setDate(date);
		
		
		
		
		try {
			vcdao.register(vc);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return "CampCreatedSuccessfully";
		
		
	}
	
	
	
	
	@RequestMapping(value  = "/CreateVaccinator.htm", method = RequestMethod.POST)
	public String vaccinatorCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		HttpSession session = request.getSession();
		
		String vaccinatorFName = (String) session.getAttribute("FName");
		String userId = (String) session.getAttribute("userId");
		String vaccinatorLName = (String) session.getAttribute("LName");
		String password= (String) session.getAttribute("password");
		Address address = (Address) session.getAttribute("address");
		int hospitalId = (Integer) session.getAttribute("hospitalId");
		
		
		String VDesignation = request.getParameter("VDesignation");
		
		
		//if(userId.equals())
		
//		System.out.println("You are here");
//		System.out.println(sdao.searchuserId(userId).getUserId());
			
//			if (sdao.searchuserId(userId).equals(""))
//			{
//				
//				
				Vaccinator vaccinator = new Vaccinator();
				vaccinator.setfName(vaccinatorFName);
				vaccinator.setlName(vaccinatorLName);
				vaccinator.setUserPassword(password);
				vaccinator.setUserId(userId);
				vaccinator.setAddress(address);
				vaccinator.setVaccinatorPosition(VDesignation);
				vaccinator.setHospitalid(hospitalId);
				vaccinator.setRole("Vaccinator");
				
				
				try {
					vdao.register(vaccinator);
				} catch (UserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					return "DoctorSuccessful";
				
				
				
			}
//			else
//							
//			{
//				
//				model.addAttribute("error", "UserId already exists");
//				return "CreateStaff";
//				
//				}
			
		
	
	
	
	
	@RequestMapping(value  = "/CreateBeneficiary.htm", method = RequestMethod.GET)
	public String benCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		
		List<Hospital> hospital = hdao.searchHospital();
		model.addAttribute("hospitallist", hospital);
		
			return "CreateBeneficiary";
		
		
	}
	
	
	@RequestMapping(value  = "/CreateBeneficiary.htm", method = RequestMethod.POST)
	public String beneficiaryCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		
		
			
			String beneficiaryName = request.getParameter("BenName");
			int beneficiaryAge = Integer.parseInt(request.getParameter("BenAge"));
			String bFatherName = request.getParameter("FatherName");
			String bMotherName = request.getParameter("MotherName");
			int hospitalId = Integer.parseInt(request.getParameter("hospSelect"));
			
			
			System.out.println("hospitalId");
			System.out.println(hospitalId);
			
			Beneficiary ben = new Beneficiary();
			
			ben.setBeneficiaryAge(beneficiaryAge);
			ben.setBeneficiaryName(beneficiaryName);
			ben.setbFatherName(bFatherName);
			ben.setbMotherName(bMotherName);
			ben.setHospitalId(hospitalId);
			
			bdao.register(ben);			
			
			return "CreateBeneficiary";
		
		
	}
	
	
	
	
	
	
	
	

}
