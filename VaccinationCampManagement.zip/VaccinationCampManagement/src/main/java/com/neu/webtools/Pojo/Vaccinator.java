package com.neu.webtools.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Vaccinator extends Staff{

	
	
	@Column(name = "VaccinatorPosition")
	private String vaccinatorPosition;
	
	
	public Vaccinator() {}

	
	public String getVaccinatorPosition() {
		return vaccinatorPosition;
	}

	public void setVaccinatorPosition(String vaccinatorPosition) {
		this.vaccinatorPosition = vaccinatorPosition;
	}
	
}
