package com.neu.webtools.Controller;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;

import com.neu.webtools.Dao.VaccinationCampDao;
import com.neu.webtools.PDF.MyPdfViewImpl;
import com.neu.webtools.Pojo.VaccinationCamp;

@Controller
public class PDFController {
	
	@Autowired
	VaccinationCampDao vcdao;
	
	
	@RequestMapping(value = "/VaccinationCampDetails.pdf", method = RequestMethod.GET)
    public View report(Locale locale, Model model,HttpServletRequest req) {
    
	
    List<VaccinationCamp> vaccinationCamp=vcdao.getVaccinationCamp();
    View view=new MyPdfViewImpl(vaccinationCamp);
    return view;
    }
	

	@RequestMapping(value = "*/VaccinationCampDetails.pdf", method = RequestMethod.GET)
    public View reports(Locale locale, Model model,HttpServletRequest req) {
    
	
    List<VaccinationCamp> vaccinationCamp=vcdao.getVaccinationCamp();
    View view=new MyPdfViewImpl(vaccinationCamp);
    return view;
    }
	
	

}
