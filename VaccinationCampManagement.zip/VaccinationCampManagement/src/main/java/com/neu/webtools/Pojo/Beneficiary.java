package com.neu.webtools.Pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
public class Beneficiary {
	
	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;

	private String beneficiaryName;
	private int beneficiaryAge;
	private String bFatherName;
	private String bMotherName;
	
	private int hospitalId;
	
	public Beneficiary() {}

	
	
	public int getHospitalId() {
		return hospitalId;
	}



	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}



	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public int getBeneficiaryAge() {
		return beneficiaryAge;
	}

	public void setBeneficiaryAge(int beneficiaryAge) {
		this.beneficiaryAge = beneficiaryAge;
	}

	public String getbFatherName() {
		return bFatherName;
	}

	public void setbFatherName(String bFatherName) {
		this.bFatherName = bFatherName;
	}

	public String getbMotherName() {
		return bMotherName;
	}

	public void setbMotherName(String bMotherName) {
		this.bMotherName = bMotherName;
	}

	
	
	
	
}

