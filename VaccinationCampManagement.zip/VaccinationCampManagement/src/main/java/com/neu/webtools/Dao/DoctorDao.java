package com.neu.webtools.Dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.Session;
import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Interceptor.LoggerInterceptor;
import com.neu.webtools.Pojo.Doctor;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.VCampDetails;
import com.neu.webtools.util.HibernateUtil;




public class DoctorDao extends DAO {
	
	private static final Logger logger = LogManager.getLogger(Doctor.class);
	
	public DoctorDao()
	{
				
	}
	
	
	/*
	public Doctor register(Doctor d) throws UserException {
		try {
			begin();
			getSession().save(d);
			commit();
			return d;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}
	*/
	
	
	
	public Doctor register(Doctor d) {
		Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().withOptions().interceptor(new LoggerInterceptor()).openSession()) 
        {
			tx = session.beginTransaction();


			session.persist(d);

			logger.info("Doctor Record is saved successfully");

			tx.commit();
			
			return d;
			
		} catch (Exception e) {
			logger.error("Failed to save Person Records:" + e);
			if (tx != null)
				tx.rollback();
			throw e;
		}
		
		
	}
	
	
	
	
	
	
	
	

}
