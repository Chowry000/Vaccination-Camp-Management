package com.neu.webtools.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Doctor;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Vaccination;
import com.neu.webtools.Pojo.Vaccinator;




public class VaccinatorDao extends DAO {
	
	public VaccinatorDao()
	{
		// Need to remove this into a method. Just here so that the Tables in hibernate can be created
		
		//begin();
		//Query q = getSession().createQuery("from Hospital");
		
		
		
		
	}
	
	
	
	public Vaccinator register(Vaccinator d) throws UserException {
		try {
			begin();
			getSession().save(d);
			commit();
			return d;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}
	
	public Vaccination vaccinate(Vaccination v) throws UserException {
		try {
			begin();
			getSession().save(v);
			commit();
			return v;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while vaccinating: " + e.getMessage());
		}
	}
	
	
	
}
