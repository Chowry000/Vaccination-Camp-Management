package com.neu.webtools.Controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.webtools.Dao.BeneficiaryDao;
import com.neu.webtools.Dao.HospitalDao;
import com.neu.webtools.Dao.StaffDao;
import com.neu.webtools.Pojo.Beneficiary;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Staff;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	
	@Autowired
	StaffDao sdao;
	
	@Autowired
	HospitalDao hdao;
	
	@Autowired
	BeneficiaryDao bdao;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	//HospitalDao hdao = new HospitalDao();
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "StaffLogin";
	}
	
	
	
	@RequestMapping(value = "*/Logout.htm", method = RequestMethod.POST)
	public String LogoutAll(Locale locale, Model model, HttpServletRequest request) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "StaffLogin";
	}
	
	
	@RequestMapping(value = "/Logout.htm", method = RequestMethod.POST)
	public String Logout(Locale locale, Model model, HttpServletRequest request) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "StaffLogin";
	}
	
	
	
	
	
	@RequestMapping(value = "/admins.htm", method = RequestMethod.GET)
	public String adminhome(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value = "*/admins.htm", method = RequestMethod.GET)
	public String adminshome(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	
	@RequestMapping(value = "*/DoctorHome.htm", method = RequestMethod.GET)
	public String DoctorHome(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		List<Hospital> hospital = hdao.searchHospital();
		List<Staff> vaccinator = sdao.searchVaccinator();
					
		model.addAttribute("hospitallist", hospital);	
		model.addAttribute("vaccinatorlist", vaccinator);
		return "DoctorHome";
	}
	
	@RequestMapping(value = "/VaccinatorHome.htm", method = RequestMethod.GET)
	public String VaccinatorHome(Locale locale, Model model) {
		List<Hospital> hospital = hdao.searchHospital();
		model.addAttribute("hospitallist", hospital);	
		
		List<Beneficiary> beneficiary = bdao.searchBeneficiary();
		model.addAttribute("beneficiarylist", beneficiary);
		model.addAttribute("getAlert", "Yes");
		return "VaccinatorHome";
	}
	
	
	@RequestMapping(value = "*/VaccinatorHome.htm", method = RequestMethod.GET)
	public String VaccinatosrHome(Locale locale, Model model) {
		List<Hospital> hospital = hdao.searchHospital();
		model.addAttribute("hospitallist", hospital);	
		
		List<Beneficiary> beneficiary = bdao.searchBeneficiary();
		model.addAttribute("beneficiarylist", beneficiary);
		model.addAttribute("getAlert", "Yes");
		return "VaccinatorHome";
	}
	
	
	
	
	
}
