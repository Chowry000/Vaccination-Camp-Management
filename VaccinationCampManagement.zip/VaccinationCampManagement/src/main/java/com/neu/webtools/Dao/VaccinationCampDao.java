package com.neu.webtools.Dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Doctor;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Staff;
import com.neu.webtools.Pojo.VaccinationCamp;




public class VaccinationCampDao extends DAO {
	
	public VaccinationCampDao()
	{
		// Need to remove this into a method. Just here so that the Tables in hibernate can be created
		
		//begin();
		//Query q = getSession().createQuery("from Hospital");
		
				
	}
	
	
	public List<VaccinationCamp> getVaccinationCamp()
	{
		begin();
				
		Criteria c1 = getSession().createCriteria(VaccinationCamp.class);
		
		
			
		List<VaccinationCamp> vaccinationCamp = c1.list();
		commit();
		return vaccinationCamp;
	}
	
	public VaccinationCamp register(VaccinationCamp d) throws UserException {
		try {
			begin();
			getSession().save(d);
			commit();
			return d;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating camp: " + e.getMessage());
		}
	}
	
	

}
