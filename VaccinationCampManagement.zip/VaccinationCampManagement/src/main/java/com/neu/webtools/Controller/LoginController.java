package com.neu.webtools.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.webtools.Dao.BeneficiaryDao;
import com.neu.webtools.Dao.DoctorDao;
import com.neu.webtools.Dao.HospitalDao;
import com.neu.webtools.Dao.StaffDao;
import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Beneficiary;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Staff;
@Controller
public class LoginController {

	
	@Autowired
	StaffDao sdao;
	
	@Autowired
	HospitalDao hdao;
	
	@Autowired
	BeneficiaryDao bdao;
	
	
	@RequestMapping(value="/StaffLogin.htm", method=RequestMethod.POST)
	public String doctorCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		
		String Stafflogin = request.getParameter("stafflogin");
		String staffpassword = request.getParameter("staffpassword");
		
		Staff staff = new Staff();
		staff.setUserId(Stafflogin);
		staff.setUserPassword(staffpassword);
		
		String role = sdao.authenticateStaff(staff);
		
		if(role.equals("Doctor"))
		{
			
			List<Hospital> hospital = hdao.searchHospital();
			List<Staff> vaccinator = sdao.searchVaccinator();
						
			model.addAttribute("hospitallist", hospital);	
			model.addAttribute("vaccinatorlist", vaccinator);	
			
			return "DoctorHome";
			
		}
			else if (role.equals("Vaccinator"))
				
			{
				List<Hospital> hospital = hdao.searchHospital();
				model.addAttribute("hospitallist", hospital);	
				
				List<Beneficiary> beneficiary = bdao.searchBeneficiary();
				model.addAttribute("beneficiarylist", beneficiary);
				model.addAttribute("getAlert", "Yes");
				return "VaccinatorHome";
				
				
				
				
			}
			else
		return "InvalidCredentials";
	}
	
	
	
	
	@RequestMapping(value="*/StaffLogin.htm", method=RequestMethod.POST)
	public String doctorsCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		
		String Stafflogin = request.getParameter("stafflogin");
		String staffpassword = request.getParameter("staffpassword");
		
		Staff staff = new Staff();
		staff.setUserId(Stafflogin);
		staff.setUserPassword(staffpassword);
		
		String role = sdao.authenticateStaff(staff);
		
		if(role.equals("Doctor"))
		{
			
			List<Hospital> hospital = hdao.searchHospital();
			List<Staff> vaccinator = sdao.searchVaccinator();
						
			model.addAttribute("hospitallist", hospital);	
			model.addAttribute("vaccinatorlist", vaccinator);	
			
			return "DoctorHome";
			
		}
			else if (role.equals("Vaccinator"))
				
			{
				List<Hospital> hospital = hdao.searchHospital();
				model.addAttribute("hospitallist", hospital);	
				
				List<Beneficiary> beneficiary = bdao.searchBeneficiary();
				model.addAttribute("beneficiarylist", beneficiary);
				model.addAttribute("getAlert", "Yes");
				return "VaccinatorHome";
				
				
				
				
			}
			else
		return "InvalidCredentials";
	}
	
	
	
	
}
