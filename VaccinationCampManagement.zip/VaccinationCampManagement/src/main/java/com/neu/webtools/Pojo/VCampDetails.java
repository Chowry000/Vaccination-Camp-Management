package com.neu.webtools.Pojo;

public class VCampDetails {

	private int id;
	private String name;
	
	
	
	public VCampDetails() {}


	
	
	

	public int getId() {
		return id;
	}






	public void setId(int id) {
		this.id = id;
	}






	public String getName() {
		return name;
	}






	public void setName(String name) {
		this.name = name;
	}






	@Override
	public String toString() {
		return "VCampDetails [id=" + id + ", name=" + name + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	};
	
	
	
	
}
