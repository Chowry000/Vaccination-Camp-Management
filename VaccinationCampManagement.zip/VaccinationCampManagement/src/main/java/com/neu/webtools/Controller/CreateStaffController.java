package com.neu.webtools.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.webtools.Dao.HospitalDao;
import com.neu.webtools.Dao.StaffDao;
import com.neu.webtools.Exception.UserException;
import com.neu.webtools.Pojo.Address;
import com.neu.webtools.Pojo.Hospital;
import com.neu.webtools.Pojo.Staff;





@Controller
public class CreateStaffController {
	
	@Autowired
	HospitalDao hdao;
	
	@Autowired
	StaffDao sdao;
	
	
	@RequestMapping(value  = "/CreateStaff.htm", method = RequestMethod.GET)
	public String hospital(Model model,HttpServletRequest request,HttpServletResponse response) 
	{
		
		List<Hospital> hospital = hdao.searchHospital();
		model.addAttribute("hospitallist", hospital);
		//model.addAttribute("staff",new Staff());
		return "CreateStaff";
		
	}
	
	@RequestMapping(value  = "*/CreateStaff.htm", method = RequestMethod.GET)
	public String hospitals(Model model,HttpServletRequest request,HttpServletResponse response) 
	{
		
		List<Hospital> hospital = hdao.searchHospital();
		model.addAttribute("hospitallist", hospital);
		//model.addAttribute("staff",new Staff());
		return "CreateStaff";
		
	}
	
	
	
	@RequestMapping(value  = "*/CreateStaff.htm", method = RequestMethod.POST)
	public String staffCreates(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		HttpSession session = request.getSession();
		
		String firstName = request.getParameter("FName");
		String lastName = request.getParameter("LName");
		String userId = request.getParameter("userId");
		String password= request.getParameter("password");
		int hospitalId = Integer.parseInt(request.getParameter("hospSelect"));
		
		
		if(sdao.searchuserId(userId).size()>0)
		{
			List<Hospital> hospital = hdao.searchHospital();
			model.addAttribute("hospitallist", hospital);
			
			model.addAttribute("error", "error");
			return "CreateStaff";
			
		}
		
		else
		{
		
		Address address = new Address();
				//addressrequest.getParameter("Address");
		address.setStreet(request.getParameter("Street"));
		address.setZip(Integer.parseInt((request.getParameter("zip"))));
		
		session.setAttribute("FName", firstName);
		session.setAttribute("LName", lastName);
		session.setAttribute("userId", userId);
		session.setAttribute("password", password);
		session.setAttribute("address",address);
		session.setAttribute("hospitalId", hospitalId);
		
		
		String staff = request.getParameter("staff");
		
		//
		//h.setStaff();
		
		
		
		
		if(staff.equals("Doctor"))
			return "CreateDoctor";
		else
			return "CreateVaccinator";
		
	}
		}
	
	
	@RequestMapping(value  = "/CreateStaff.htm", method = RequestMethod.POST)
	public String staffCreate(Model model,HttpServletRequest request,HttpServletResponse response) throws UserException 
	{
		HttpSession session = request.getSession();
		
		String firstName = request.getParameter("FName");
		String lastName = request.getParameter("LName");
		String userId = request.getParameter("userId");
		String password= request.getParameter("password");
		int hospitalId = Integer.parseInt(request.getParameter("hospSelect"));
		
		
		if(sdao.searchuserId(userId).size()>0)
		{
			List<Hospital> hospital = hdao.searchHospital();
			model.addAttribute("hospitallist", hospital);
			
			model.addAttribute("error", "error");
			return "CreateStaff";
			
		}
		
		else
		{
		
		Address address = new Address();
				//addressrequest.getParameter("Address");
		address.setStreet(request.getParameter("Street"));
		address.setZip(Integer.parseInt((request.getParameter("zip"))));
		
		session.setAttribute("FName", firstName);
		session.setAttribute("LName", lastName);
		session.setAttribute("userId", userId);
		session.setAttribute("password", password);
		session.setAttribute("address",address);
		session.setAttribute("hospitalId", hospitalId);
		
		
		String staff = request.getParameter("staff");
		
		//
		//h.setStaff();
		
		
		
		
		if(staff.equals("Doctor"))
			return "CreateDoctor";
		else
			return "CreateVaccinator";
		
	}
		}
	

}
