package com.neu.webtools.PDF;


import java.util.List;
import java.util.Map;
import com.neu.webtools.Pojo.VaccinationCamp;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.DottedLineSeparator;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class MyPdfViewImpl extends AbstractPdfView{

    List<VaccinationCamp> vaccinationCamp;
    
    
    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        // TODO Auto-generated method stub
        if(vaccinationCamp!=null)
        {
//            Element e1=new Chunk(�Name : �+b.get(0).getUser().getName());
//            document.add(e1);
        	
        	
        	Element e2 = new Chunk("                          VACCINATION DUTY                                ");
        	Element e3 = new Chunk("--------------------------------------------------------------------------");
        	
        	
        	document.add(new DottedLineSeparator());
        	document.add(new VerticalPositionMark());
        	document.add(e2);
        	document.add(new DottedLineSeparator());
        	document.add(new VerticalPositionMark());
        	document.add(new VerticalPositionMark());
        	document.add(new VerticalPositionMark());
        	
        	
        
        
      Table table=new Table(3);
        table.addCell("CAMP DATE");
        table.addCell("CAMP LOCATION");
        table.addCell("VACCINATOR ON DUTY");
        
        for(VaccinationCamp vc:vaccinationCamp) {
            table.addCell(vc.getDate()+"");
            table.addCell(vc.getLocation());
            table.addCell(vc.getVaccinatorDuty());
        }
        document.add(table);
        }
    }
    
    
    public MyPdfViewImpl(List<VaccinationCamp> vaccinationCamp)
    {
        this.vaccinationCamp=vaccinationCamp;
    }

	
}