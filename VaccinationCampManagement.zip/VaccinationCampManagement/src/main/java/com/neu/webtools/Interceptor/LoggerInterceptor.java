package com.neu.webtools.Interceptor;


import java.io.Serializable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

import com.neu.webtools.Pojo.Doctor;


public class LoggerInterceptor extends EmptyInterceptor {

   private static final long serialVersionUID = 1L;
  
   private static Logger logger = LogManager.getLogger(LoggerInterceptor.class);

   @Override
   public boolean onSave(Object entity, Serializable id, Object[] state,
            String[] propertyNames, Type[] types) {
      logger.info("SAVE OPERATION GETTING PERFORMED ON DOCTOR");
      if (entity instanceof Doctor) {
    	  Doctor doctor = (Doctor) entity;
         logger.info(doctor);
      }
      return super.onSave(entity, id, state, propertyNames, types);
   }
   @Override
	public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
	   logger.info("onLoad method is called...");
	      if (entity instanceof Doctor) {
	    	  Doctor doctor = (Doctor) entity;
	          logger.info(doctor);
	      }
		return super.onLoad(entity, id, state, propertyNames, types);
	}
}